<?php
$conn = new mysqli("localhost", "root", "", "bac");
$login = isset($_GET['login']) ? $_GET['login'] : null; 
$id = isset($_GET['id']) ? $_GET['id'] : null; 
$user = null;

if ($login !== null) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
}elseif ($id !== null) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE userid = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
}
?>


<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Broken Access Control</title>
    <link rel="stylesheet" type="text/css" href="/owasp-top-10/assets/css/styles-vul.css">
</head>
<body>
<div class="content">
        <h1>OWASP Top 10 - Podatność 1: Broken Access Control</h1>
</div>
<section>
    <h2>Omówienie Ataku</h2>
    <p>Kontrola dostępu ogranicza użytkownika do działania w ramach zamierzonych przez twórcę uprawnień. Awaria kontroli dostępu będzie skutkować brakiem ograniczeń dostępu dla zwykłych użytkowników, może to doprowadzić do ujawnienia informacji poufnych, nieuprawnionej modyfikacji lub usunięcia danych.</p>
    <br>
    <h3>Do najczęstszych podatności na ataki typu Broken Access Control należą:</h3>
    <br>
    <ul>
        <li>Naruszenie zasady principle of least privilege - dostęp powinien być przyznawany tylko w określonych przypadkach, dla określonych ról lub użytkowników, ale jest przyznawany każdemu.</li>
        <li>Omijanie kontroli dostępu poprzez modyfikację adresu URL - zamiana parametrów lub wymuszenie wyszukiwania.</li>
        <li>Zezwolenie na przeglądanie lub edycję konta poprzez podanie jej unikalnego identyfikatora - bezpośrednie odniesienia do obiektów.</li>
        <li>Dostęp do API z brakującymi kontrolami dostępu dla POST, PUT i DELETE.</li>
        <li>Eskalacja uprawnień - działanie jako użytkownik bez zalogowania się lub działanie jako administrator po zalogowaniu się jako użytkownik.</li>
        <li>Manipulacja metadanymi - manipulowanie tokenem kontroli dostępu JSON Web Token(JWT) lub ukrytym polem w celu eskalacji uprawnień lub unieważnienia JWT.</li>
        <li>Błędna konfiguracja Cross-Origin Resource Sharing - umożliwia dostęp do API z nieautoryzowanych/niezaufanych źródeł.</li>
    </ul></p>
</section>
<?php if($user): ?>
    <div class="content">
    <h2>User Details</h2>
    <p>ID: <?= $user['userid'] ?></p>
    <p>Email: <?= $user['email'] ?></p>
    <p>Login: <?= $user['login'] ?></p>
    <p>Password: <?= $user['password'] ?></p>
    </div>
<?php else: ?>

    <form action="" method="get">
        <label for="id">ID:</label><br>
        <input type="text" id="id" name="id"><br>
        
        <label for="login">Login:</label><br>
        <input type="text" id="login" name="login"><br>
        
        <input type="submit" value="Submit">
    </form>
<?php endif; ?>

</body>
</html>


