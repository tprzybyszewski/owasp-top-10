<?php
$search = "";
$result = null;
if (isset($_GET["search"])) {
    $search = $_GET["search"];
}

$conn = new mysqli("localhost", "root", "", "Injection");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM Users WHERE name = '$search'";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html>

<head>
    <title>Injection</title>
    <link rel="stylesheet" type="text/css" href="/owasp-top-10/assets/css/styles-vul.css">
    <meta charset="UTF-8">
</head>

<body>
    <div class="content">
        <h1>OWASP Top 10 - Podatność 3: Injection</h1>
    </div>
    <section>
    <h2>Omówienie Ataku</h2>
    <p>Podatność na ataki typu Incjection pozwala atakującym wprowadzić złośliwe dane wejściowe do aplikacji lub przekazywać złośliwy kod przez aplikację do innego systemu. Podczas tego ataku niezaufane dane wejściowe lub nieutoryzowany kod są "wstrzykiwane" do programu i interpretowanie jako część zapytania lub polecenia. Rezultatem jest zmiana działania programu, przekierowująca go do realizacji szkodliwych celów.</p>
    <br>
    <h3>Do najczęstszych podatności na ataki typu Incjection należą:</h3>
    <br>
    <ul>
        <li>Dane dostarczone przez użytkownika nie są weryfikowane, filtrowane lub oczyszczane przez aplikację.</li>
        <li>Używane są dynamiczne zapytania lub niestandardowe wywołania bez uwzględniania kontekstu, które są bezpośrednio interpretowane.</li>
        <li>Dane są wykorzystywane w parametrach wyszukiwania mapowania obiektowo-relacyjnego (\textbf{Object-relational mapping}) do wydobywania dodatkowych, wrażliwych rekordów.</li>
        <li>Dane są używane bezpośrednio lub są konkatenowane - Zapytanie SQL lub inna komenda zawiera strukturę i złośliwe dane w dynamicznych zapytaniach, poleceniach lub procedurach składowanych.</li>
    </ul></p>

</section>
    <form action="" method="get">
            <label for="search">Szukaj użytkownika:</label>
            <input type="text" id="search" name="search" placeholder="Search...">
            <input type="submit" value="Szukaj">
    </form>
    <div class="content">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "ID: " . $row["id"] . " - Imię: " . $row["name"] . "<br>";
            }
        }
        $conn->close();
        ?>
    </div>
</body>
</html>