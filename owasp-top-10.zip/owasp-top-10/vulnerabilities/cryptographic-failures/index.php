<?php
$conn = new mysqli("localhost", "root", "", "cryptographic-failures");

$login = isset($_POST['login']) ? $_POST['login'] : null; 
$password = isset($_POST['password']) ? $_POST['password'] : null; 
$email = isset($_POST['email']) ? $_POST['email'] : null; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if ($login !== null && $password !== null && $email !== null){
        $login = $_POST['login'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $hashedPassword = md5($password);
        $stmt = $conn->prepare("INSERT INTO users (login, password_hashed, email) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $login, $hashedPassword, $email);

        if ($stmt->execute()) {
            echo "<div class='content'>Użytkownik został zarejestrowany.</div>";
        } else {
            echo "Błąd: " . $stmt->error;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title a href="/owasp-top-10/index.html">Cryptographic Failures</title>
    <link rel="stylesheet" type="text/css" href="/owasp-top-10/assets/css/styles-vul.css">
</head>
<body>
<div class="content">
        <h1>OWASP Top 10 - Podatność 2: Cryptographic Failures</h1>
</div>
<section>
    <h2>Omówienie Ataku</h2>
    <p>Ataki występują kiedy atakujący kierują swoje działania na wrażliwe dane, takie jak hasła, numery kart kredytowych i informacje osobiste, gdy nie są one odpowiednio chronione. Jest to podstawowa przyczyna narażenia wrażliwych danych na ryzyko.</p>
    <br>
    <h3>Do najczęstszych podatności na ataki typu Cryptographic Failures należą:</h3>
    <br>
    <ul>
    <li> Stare lub słabe algorytmy kryptograficzne - Istotne jest unikanie stosowania starych lub słabych algorytmów lub protokołów kryptograficznych, zarówno domyślnie, jak i w starszym kodzie.</li>
    <li> Wymuszenie szyfrowania - Ważne jest, aby wymuszać szyfrowanie, na przykład przez stosowanie odpowiednich dyrektyw lub nagłówków bezpieczeństwa w przeglądarkach.</li>
    <li> Losowość w celach kryptograficznyc - Ważne jest, aby do celów kryptograficznych wykorzystywać losowość, która została zaprojektowana do spełnienia wymagań kryptograficznych i nie była ziarnowana w przewidywalny sposób lub z niską entropią.</li>
    <li> Przestarzałe funkcje hashowania - Należy unikać stosowania przestarzałych funkcji haszujących, takich jak MD5 czy SHA1, oraz niekryptograficznych funkcji haszujących tam, gdzie potrzebne są kryptograficzne.</li>
    <li> Hasła jako klucze kryptograficzne - Nie należy używać haseł jako kluczy kryptograficznych bez funkcji pochodzenia klucza opartej na haśle.</li>
    </ul></p>
</section>
    <form method="POST">
        <label for="login">Nazwa użytkownika:</label><br>
        <input type="text" id="login" name="login" required><br>
        <label for="password">Hasło:</label><br>
        <input type="password" id="password" name="password" required><br>
        <label for="email">E-mail:</label><br>
        <input type="text" id="email" name="email" required><br><br>
        <input type="submit" value="Zarejestruj">
    </form>
    <div class="content">
<?php
    if (isset($_POST['show_db'])) {
        $sql = "SELECT * FROM users"; 
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "id: " . $row["userid"]. " - Nazwa użytkownika: " . $row["login"]. " - Hasło: " . $row["password_hashed"]." - Email: " . $row["email"]. "<br>";
            }
        } else {
            echo "Baza danych jest pusta";
        }
    }
?>
</div>
    <br><br><br><br>
    <form method="post">
        <input type="submit" name="show_db" value="Wyświetl bazę danych (w celach demonstracyjnych)">
    </form>
</body>
</html>