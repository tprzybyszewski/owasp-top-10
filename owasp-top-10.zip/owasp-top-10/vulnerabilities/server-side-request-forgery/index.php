<?php
if (isset($_GET['url'])) {
    $url = $_GET['url'];
    $content = file_get_contents($url);
    echo $content;
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Security Misconfiguration</title>
    <link rel="stylesheet" type="text/css" href="/owasp-top-10/assets/css/styles-vul.css">
    <meta charset="UTF-8">
</head>

<body>
    <div class="content">
        <h1>OWASP Top 10 - Podatność 10: Server-Side Request Forgery (SSRF)</h1>
    </div>
    <section>
    <h2>Omówienie Ataku</h2>
    <p>Luki w SSRF pojawiają się, gdy aplikacja internetowa pobiera zasób zdalny bez weryfikacji podanego przez użytkownika adresu URL. Pozwala to atakującemu zmusić aplikację do wysłania spreparowanego żądania do nieoczekiwanego miejsca docelowego, nawet jeśli jest chroniona przez firewall, VPN lub inną listę kontroli dostępu do sieci. Wraz z rozwojem nowoczesnych aplikacji internetowych, które oferują użytkownikom wygodne funkcje, pobieranie adresu URL staje się powszechnością. W rezultacie SSRF jest coraz powszechniejszym atakiem. Dodatkowo, powaga ataków SSRF wzrasta ze względu na usługi chmurowe i złożoność architektur.</p>
    </section>

<form action="" method="get">
    <label for="url">URL:</label>
    <input type="text" id="url" name="url">
    <input type="submit" value="Fetch content">
</form>

</body>
</html>
