<?php
$conn = new mysqli("localhost", "root", "", "identification-failures");

$login = isset($_POST['login']) ? $_POST['login'] : null; 
$password = isset($_POST['password']) ? $_POST['password'] : null; 

if (isset($_POST['login']) && isset($_POST['password'])) {
    $username = $_POST['login'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE login = ? AND password = ?");
    $stmt->bind_param("ss", $login, $password);
    $stmt->execute();
    $result = $stmt->get_result();

}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title a href="/owasp-top-10/index.html">Identification and Authentication Failures</title>
    <link rel="stylesheet" type="text/css" href="/owasp-top-10/assets/css/styles-vul.css">
</head>
<body>
<div class="content">
        <h1>OWASP Top 10 - Podatność 7: Identification and Authentication Failures</h1>
</div>
<section>
    <h2>Omówienie Ataku</h2>
    <p>Identification and Authentication Failures to podatności związane ze schematami uwierzytelniania aplikacji. Takie wady mogą prowadzić do poważnych i szkodliwych naruszeń ochrony danych.</p>
    <br>
    <h3>Potwierdzenie tożsamości użytkownika, uwierzytelnienie i zarządzanie sesją są kluczowe dla ochrony przed atakami związanymi z uwierzytelnieniem. Aplikacja może posiadać słabości w uwierzytelnieniu, jeśli:</h3>
    <br>
    <ul>
    <li>Pozwala na automatyczne ataki - Umożliwia ataki typu credential stuffing, gdzie atakujący dysponuje listą prawidłowych nazw użytkowników i haseł.</li>
    <li>Pozwala na ataki brute force lub Inne automatyzowane ataki - Nie zabezpiecza przed atakami metodą prób i błędów lub innymi automatyzowanymi metodami ataku.</li>
    <li>Pozwala na używanie domyślnych, słabych lub powszechnie znanych haseł - Umożliwia używanie słabych lub powszechnie znanych haseł, takich jak "Password1" czy "admin/admin".</li>
    <li>Używa słabych lub nieefektywnych procesów odzyskiwania loginów i haseł - Stosuje niebezpieczne procesy odzyskiwania zapomnianych haseł, takie jak odpowiedzi na pytania oparte na wiedzy ogólnodostępnej.</li>
    <li>Przechowuje hasła w postaci jawnej, szyfrowanej lub sabo zahashowanej - Używa jawnych, szyfrowanych lub słabo zahaszowanych haseł w magazynach danych (\textbf{Cryptographic Failures}).</li>
    <li>Brak lub nieefektywne uwierzytelnianie wieloskładnikowe.</li>
    <li>Ujawnia identyfikator sesji w adresie URL.</li>
    <li>Ponowne używanie identyfikatora sesji po pomyślnym logowaniu.</li>
    <li>Nieprawidłowe unieważnianie identyfikatorów sesji - Sesje użytkowników lub tokeny uwierzytelniania (szczególnie w przypadku pojedynczego logowania, SSO) nie są odpowiednio unieważniane podczas wylogowania lub po okresie nieaktywności.</li>
    </ul></p>
</section>
    <form method="POST">
        <label for="login">Nazwa użytkownika:</label><br>
        <input type="text" id="login" name="login" required><br>
        <label for="password">Hasło:</label><br>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Zaloguj">
    </form>
    <div class="content">
    <?php
    if(isset($result)){
    if ($result->num_rows > 0) {
        echo "Logowanie udane!";
    } else {
        echo "Logowanie nieudane: nieprawidłowa nazwa użytkownika lub hasło.";
    }}
    ?>
    </div>

    <br><br><br><br>
    <form method="post">
        <input type="submit" name="show_db" value="Wyświetl bazę danych (w celach demonstracyjnych)">
    </form>
    <div class="content">
<?php
    if (isset($_POST['show_db'])) {
        $sql = "SELECT * FROM users"; 
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "id: " . $row["login"]. " - Nazwa użytkownika: " . $row["login"]. " - Hasło: " . $row["password"]."<br>";
            }
        } else {
            echo "Baza danych jest pusta";
        }
    }
?>
</div>
</body>
</html>