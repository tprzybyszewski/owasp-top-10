<?php
$conn = new mysqli("localhost", "root", "", "insecure-design");

$login = isset($_POST['login']) ? $_POST['login'] : null; 
$answer = isset($_POST['security-answer']) ? $_POST['security-answer'] : null; 
$password = isset($_POST['password']) ? $_POST['password'] : null; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if ($login !== null && $password !== null && $answer !== null){
        $login = $_POST['login'];
        $answer = $_POST['security-answer'];
        $password = $_POST['password'];

        $stmta = $conn->prepare("SELECT security_answer FROM users WHERE login = ?");
        $stmta->bind_param("s", $login);
        $stmta->execute();
        $result = $stmta->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            $databaseAnswer = $row['security_answer'];
            
            if($answer == $databaseAnswer){

                $stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE login = ?");
                $stmt->bind_param("ss", $password, $login);
                if ($stmt->execute()) {
                    echo "<div class='content'>Hasło zostało zaktualizowane.</div>";
                }
                $stmt->close();
            } else {
                echo "<div class='content'>Nieprawidłowa odpowiedź zabezpieczająca.</div>";
            }
        } else {
            echo "<div class='content'>Nie znaleziono użytkownika o podanym loginie.</div>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title a href="/owasp-top-10/index.html">Insecure Design</title>
    <link rel="stylesheet" type="text/css" href="/owasp-top-10/assets/css/styles-vul.css">
</head>
<body>
<div class="content">
        <h1>OWASP Top 10 - Podatność 4: Insecure Design</h1>
</div>
<section>
    <h2>Omówienie Ataku</h2>
    <p>Ataki typu Insecure Design to obszerna kategoria obejmująca różne słabości, określane jako "brakujące lub nieskuteczne projektowanie kontroli". Istnieje różnica między niebezpiecznym projektowaniem a niebezpieczną implementacją. Rozróżniamy wady projektowania i wady implementacji z ważnego powodu - mają one różne przyczyny i wymagają odmiennych środków zaradczych. Bezpieczny projekt może nadal posiadać wady implementacyjne prowadzące do podatności, które mogą zostać wykorzystane. Niebezpieczny projekt nie może zostać naprawiony przez perfekcyjną implementację, ponieważ niezbędne kontrole bezpieczeństwa nigdy nie zostały stworzone, aby bronić przed konkretnymi atakami. Jednym z czynników przyczyniających się do niebezpiecznego projektowania jest brak profilowania ryzyka w oprogramowaniu lub systemie, który jest rozwijany, a co za tym idzie brak zdolności do ustalenia wymaganego poziomu projektowania bezpieczeństwa.</p>
<!--<br>
    <h3>Przykładowy atak wykorzystujący Insecure Design może zostać przeprowadzony w kilku krokach:</h3>
    <br>
    <ul>
    <li>Analiza systemu - Atakujący zauważa, że sieć kin oferuje zniżki grupowe i pozwala na rezerwację do 15 miejsc na jedną grupę bez konieczności wpłaty zaliczki. Atakujący analizuje ten proces rezerwacji i modeluje potencjalne zagrożenia.</li>
    <li>Wyszukanie luki w procesie rezerwacji - Atakujący odkrywa, że system rezerwacji nie ma mechanizmów ograniczających liczbę jednoczesnych rezerwacji dokonywanych przez jednego użytkownika lub z jednego adresu IP.</li>
    <li>Przeprowadzenie ataku - Wykorzystując tę lukę, atakujący opracowuje skrypt lub program, który automatycznie dokonuje wielu rezerwacji na maksymalną liczbę osób jednocześnie w wielu kinach. Na przykład, atakujący może zarezerwować 600 miejsc w różnych kinach, wypełniając wszystkie dostępne seanse, nie ponosząc przy tym żadnych kosztów zaliczki.</li>
    <li>Efekt ataku - W wyniku tego ataku, prawdziwi klienci nie mogą dokonać rezerwacji, co prowadzi do znaczących strat finansowych dla sieci kin. Ponadto, ze względu na brak zaliczki, atakujący nie ponosi żadnego ryzyka finansowego.</li>
    </ul></p>-->
</section>
    <form method="POST">
        <label for="login">Nazwa użytkownika:</label><br>
        <input type="text" id="login" name="login" required><br>
        <label for="security-answer">Jakie jest twoje ulubione zwierzę?:</label><br>
    <input type="text" id="security-answer" name="security-answer" required><br>
    <label for="password">Nowe Hasło:</label><br>
    <input type="password" id="password" name="password" required><br><br>
    <input type="submit" value="Resetuj Hasło">
    </form>
    <div class="content">
<?php
    if (isset($_POST['show_db'])) {
        $sql = "SELECT * FROM users"; 
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "id: " . $row["id"]. " - Nazwa użytkownika: " . $row["login"]. " - Hasło: " . $row["password_hash"]." - Odpowiedź: " . $row["security_answer"]. "<br>";
            }
        } else {
            echo "Baza danych jest pusta";
        }
    }
?>
</div>
    <br><br><br><br>
    <form method="post">
        <input type="submit" name="show_db" value="Wyświetl bazę danych (w celach demonstracyjnych)">
    </form>
</body>
</html>